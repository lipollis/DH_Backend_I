package com.example.pacote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PacoteApplication {

	public static void main(String[] args) {
		SpringApplication.run(PacoteApplication.class, args);
	}

}
