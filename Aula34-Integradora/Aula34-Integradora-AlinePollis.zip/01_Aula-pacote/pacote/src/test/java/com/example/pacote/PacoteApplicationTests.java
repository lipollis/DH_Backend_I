package com.example.pacote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PacoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
