package com.dh.clinica.repository.impl;

import com.dh.clinica.model.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurnoRepository extends JpaRepository<Turno, Integer> {
}
