package Serie;

public interface ISerie {
    public String getSerie(String nomeSerie) throws SerieNaoHabilitadaException;
}
