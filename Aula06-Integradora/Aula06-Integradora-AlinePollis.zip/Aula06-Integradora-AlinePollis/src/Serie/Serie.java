package Serie;

public class Serie{

    // IMPLEMENTAÇÃO DO MÉTODO
    public String getSerie(String nomeSerie) {
        return "www." + nomeSerie + ".com";
    }
}
