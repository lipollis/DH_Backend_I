package Serie;

public class SerieNaoHabilitadaException extends Exception{

    public SerieNaoHabilitadaException() {
        super();
    }

    public SerieNaoHabilitadaException(String message) {
        super(message);
    }
}
