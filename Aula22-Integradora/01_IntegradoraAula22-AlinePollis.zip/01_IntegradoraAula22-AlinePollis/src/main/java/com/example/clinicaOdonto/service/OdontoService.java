package com.example.clinicaOdonto.service;

import com.example.clinicaOdonto.model.Dentista;

import java.util.Map;

// INTERFACE USANDO O 'T' PARA SERVIR PARA TODOS OS SERVICES
public interface OdontoService<T> {
    //T salvar(T t);
    Dentista salvar(Dentista dentista);

    T buscarId(Integer id);
    Map<Integer, T> buscarTodos();

    //T atualizar(T t);
    Dentista atualizar(Dentista dentista);

    void deletar(Integer id);
}
