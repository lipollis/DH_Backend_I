DROP TABLE IF EXISTS `dentista`
CREATE TABLE `dentista` 
(`id` int auto_increment PRIMARY KEY,
`matricula` varchar(15),
`nome` varchar(50),
`sobrenome` varchar(50)
);