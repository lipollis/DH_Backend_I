package com.dh.productos.controller;

import com.dh.productos.model.Produto;
import com.dh.productos.servicio.ProdutoService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/produtos")
public class ProdutoController {


    private ProdutoService produtoService;

    public ProdutoController(ProdutoService produtoService) {
        this.produtoService = produtoService;
    }

    @PostMapping
    public Produto guardarProduto(@RequestBody Produto p){
        return produtoService.guardar(p);
    }

    @GetMapping
    public List<Produto> listar(){
        return produtoService.listar();
    }

    @DeleteMapping("/{id}")
    public String apagar(@PathVariable Integer id){
        produtoService.apagar(id);
        return "eliminado";
    }

    @GetMapping("/{id}")
    public Produto buscar(@PathVariable Integer id){
        return produtoService.buscar(id);
    }
}
