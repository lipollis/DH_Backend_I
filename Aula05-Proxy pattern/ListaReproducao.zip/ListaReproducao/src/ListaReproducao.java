import java.util.ArrayList;
import java.util.List;

public class ListaReproducao {
    private String nomeLista;
    private List<Musica> lista;

    public ListaReproducao(String nomeLista) {
        this.nomeLista = nomeLista;
        this.lista = new ArrayList<>();
    }

    public String getNomeLista() {
        return nomeLista;
    }

    public void setNomeLista(String nomeLista) {
        this.nomeLista = nomeLista;
    }

    public void add(final Musica musica) {
        this.lista.add(musica);
    }

    @Override
    public String toString() {
        return "ListaReproducao [nomeLista=" + nomeLista + ", lista=" + lista.toString() + "]";
    }
}
