import java.util.HashMap;
import java.util.Objects;

public class MusicFactory {
    private static final HashMap<String, Musica> MUSICA = new HashMap<>();

    public Musica obterMusica(final String nome, final String artista, final String genero) {
        Musica musica = MUSICA.get(nome);
        if (Objects.isNull(musica)) {
            musica = new Musica(nome, artista, genero);
            MUSICA.put(nome, musica);
            System.out.println("Música criada");
            return musica;
        }
        System.out.println("Musica recuperada");
        return musica;
    }
}
