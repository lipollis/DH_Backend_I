public class Main {
    public static void main(String[] args) {

        final MusicFactory musicFactory = new MusicFactory();
        final ListaReproducao lista1 = new ListaReproducao("ListaPop");
        lista1.add(musicFactory.obterMusica("faded", "Maroon 5", "pop"));
        lista1.add(musicFactory.obterMusica("sugar", "Maroon 5", "pop"));
        lista1.add(musicFactory.obterMusica("sugar", "kindom", "pop"));

        System.out.println(lista1.toString());
    }
}
